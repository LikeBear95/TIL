import requests
from pprint import pprint


def best_review_books():
    URL = 'http://www.aladin.co.kr/ttb/api/ItemSearch.aspx'
    params = {
        'ttbkey': '부여받은 TTBKey',
        'Query': '파울로 코엘료',
        'QueryType': 'Author',
        'MaxResults' : 20,
        'start' : 1,
        'SearchTarget' : 'Book',
        'output' : 'js',
        'Version' : '20131101'
    }

    response = requests.get(URL, params=params).json()
    result = []
    for book in response['item']:
      if book['customerReviewRank'] >= 9:
        result.append(book)
    return result


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    """
    파울로 코엘료 도서목록중 customReviewRank가 9 이상인 도서목록 반환
    (주의) 도서목록의 경우 시기에 따라 아래 예시 출력과 차이가 있을 수 있음
    """
    pprint(best_review_books())
    """
    [
      {
        'adult': False,
        'author': '파울로 코엘료 (지은이), 최정수 (옮긴이)',
        'categoryId': 50920,
        'categoryName': '국내도서>소설/시/희곡>스페인/중남미소설',
        'cover': 'https://image.aladin.co.kr/product/30/73/coversum/8982814477_3.jpg',
        'customerReviewRank': 9,
        'description': "세상을 두루두루 여행하기 위해 양치기가 된 청년 산티아고의 '자아의 신화' 찾기 여행담. 자칫 딱딱하게 보일 "
                      '수 있는 제목과는 달리 간결하고 경쾌한 언어들로 쓰여 있어서, 물이 흘러가듯 수월하게 읽히는 작품이다.',
        'fixedPrice': True,
        'isbn': '8982814477',
        'isbn13': '9788982814471',
        'itemId': 307361,
        'link': 'http://www.aladin.co.kr/shop/wproduct.aspx?ItemId=307361&amp;partner=openAPI&amp;start=api',
        'mallType': 'BOOK',
        'mileage': 600,
        'priceSales': 10800,
        'priceStandard': 12000,
        'pubDate': '2001-12-01',
        'publisher': '문학동네',
        'salesPoint': 85613,
        'stockStatus': '',
        'subInfo': {},
        'title': '연금술사'},
      },
      {'adult': False,
          ..생략..,
      }
    ]
    """
