import requests
from pprint import pprint


def bestseller_book():
    URL = 'http://www.aladin.co.kr/ttb/api/ItemSearch.aspx'
    params = {
        'ttbkey': '부여받은 TTBKey',
        'Query': '파울로 코엘료',
        'QueryType': 'Author',
        'MaxResults' : 20,
        'start' : 1,
        'SearchTarget' : 'Book',
        'output' : 'js',
        'Version' : '20131101'
    }

    response = requests.get(URL, params=params).json()
    result = []
    book_list = response['item']
    book_list.sort(key=lambda x: x['salesPoint'], reverse=True)
    """
      sorted 함수 사용
      '''
        sorted_book_list = sorted(book_list, key=lambda x: x['salesPoint'], reverse=True)
        result = sorted_book_list[:5]
      '''
    """

    for best_Book in book_list[:5]:
        result.append(best_Book['title'])

   
    return result


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    """
    도서목록을 정렬하여 판매지수가 높은 5개 도서 반환

    판매지수(salePoint) 
        '''
          판매지수는 판매량과 판매기간에 근거해 알라딘 자체적인 가중치를 통해 계산한 알라딘 자체 지수.
          가중치 개념을 소개하기 좋은 예시
        ''' 
        
    (주의) 도서목록의 경우 시기에 따라 아래 예시 출력과 차이가 있을 수 있음
    """
    pprint(bestseller_book())
    """
    ['연금술사', '11분', '다섯번째 산', '브리다', '흐르는 강물처럼']
    """
