import requests
from pprint import pprint


def ebook_list(title):
    URL = 'http://www.aladin.co.kr/ttb/api/ItemSearch.aspx'
    params = {
        'ttbkey': '부여받은 TTBKey',
        'Query': {title},
        'QueryType': 'Title',
        'MaxResults' : 1,  # 첫 번쩨 도서
        'start' : 1,
        'SearchTarget' : 'Book',
        'output' : 'js',
        'Version' : '20131101',
        'OptResult': 'ebookList' # ebook 조회
    }
    response = requests.get(URL, params=params).json()

    # 검색 결과가 없는 도서는 None 리턴
    if len(response['item']) == 0 :
        return 

    # 검색한 도서의 가격과 ebook 정보 
    price = response['item'][0]['priceSales']
    ebook_list = response['item'][0]['subInfo']['ebookList']

    
    # ebook과 종이 서적의 가격을 비교 후 10% 이상 저렴한 ebook 목록 출력
    result = []
    for ebook in ebook_list:
        if ebook['priceSales'] <= (price * 0.9) :
            tmp = {
            'itemId': ebook['itemId'],
            'isbn': ebook['isbn'],
            'priceSales': ebook['priceSales'],
            'link': ebook['link'],
            }
            result.append(tmp)

    return result  


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    """
    도서 검색에 실패할 경우 None을 반환
    (주의) 검색 도서 작가 검색 결과의 경우 아래 예시 출력과 차이가 있을 수 있음
    """
    pprint(ebook_list('베니스의 상인'))

    pprint(ebook_list('*'))
