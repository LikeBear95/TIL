import pprint
import requests

def get_deposit_products():
    api_key = "비밀"

    url = 'http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json'
    params = {
        'auth': api_key,
        'topFinGrpNo': '020000',
        'pageNo': 1
    }
    response = requests.get(url, params=params).json()
    return response

response = get_deposit_products()
result = response['result'].keys()
pprint.pprint(result)