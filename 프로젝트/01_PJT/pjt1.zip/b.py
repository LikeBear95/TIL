import pprint
import requests


def get_deposit_products():
    api_key = "72624f4493711e1a4b021f735bffa37e"

    url = 'http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json'
    params = {
        'auth': api_key,
        'topFinGrpNo': '020000',
        'pageNo': 1
    }
    response = requests.get(url, params=params).json()
    return response
json_response = get_deposit_products()
result = json_response['result']['baseList']
pprint.pprint(result)