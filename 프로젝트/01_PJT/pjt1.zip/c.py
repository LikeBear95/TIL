import pprint
import requests

def get_deposit_products():
    api_key = "72624f4493711e1a4b021f735bffa37e"

    url = 'http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json'
    params = {
        'auth': api_key,
        'topFinGrpNo': '020000',
        'pageNo': 1
    }
    option_list = requests.get(url, params=params).json()['result']['optionList']
    result = []
    for option in option_list:
        new_option = {}
        new_option['금융상품코드'] = option['fin_prdt_cd']
        new_option['저축금리유형'] = option['intr_rate_type']
        new_option['저축금리유형명'] = option['intr_rate_type_nm']
        new_option['저축 기간'] = option['save_trm']
        new_option['저축 금리'] = option['intr_rate']
        new_option['최고 우대금리'] = option['intr_rate2']
        result.append(new_option)
     
    return result
result = get_deposit_products()
pprint.pprint(result)