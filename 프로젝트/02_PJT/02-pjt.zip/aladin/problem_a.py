import requests


def author_works():
    # 여기에 코드를 작성합니다.  
    pass



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':

    print(author_works())

    