import requests
from pprint import pprint


def ebook_list(title):
    # 여기에 코드를 작성합니다.  
    pass



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':

    pprint(ebook_list('베니스의 상인'))

    pprint(ebook_list('*'))
