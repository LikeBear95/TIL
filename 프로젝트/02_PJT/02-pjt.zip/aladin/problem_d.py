import requests
from pprint import pprint


def author_other_works(title):
    # 여기에 코드를 작성합니다.  
    pass



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':

    pprint(author_other_works('베니스의 상인'))

    pprint(author_other_works('개미'))

    pprint(author_other_works('*'))
